#include "getbackpwd.h"
#include "ui_getbackpwd.h"
#include "loginwindow.h"
#include "mainwindow.h"

#include <QMessageBox>
#include <QKeyEvent>


Getbackpwd::Getbackpwd(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Getbackpwd)
{
    ui->setupUi(this);
    setWindowTitle("找回密码");
    connect( ui ->yes_btn, SIGNAL(clicked()), this,SLOT( judgeEmpty() ) );
    //new start
    connect( ui ->checkExist_btn, SIGNAL(clicked()), this,SLOT( judgeExist() ) );
    ui ->ques_lb ->setText("这里是没有变化的");
    connect( ui ->cancel_btn, SIGNAL(clicked()), this,SLOT( cancelToMain() ) );
    //new end
    extern QString backGroundColor;
    this -> setStyleSheet(backGroundColor);

    QString IP = "192.168.43.11";
    int port = 8765;

    client = new QTcpSocket();

    //取消已有的连接
    client->abort();

    //连接服务器
    client->connectToHost(IP, port);

    //等待连接成功
    if(!client->waitForConnected(30000))
    {
        qDebug() << "Connection failed!";
        return;
    }
}

Getbackpwd::~Getbackpwd()
{
    delete ui;
}

void Getbackpwd::keyPressEvent(QKeyEvent *event){//有错误！先不管了！
    /*qDebug()<<"in KeyPressed,eventkey"<<event->key()<<endl;
    if(event->key() == Qt::Key_Return || event->key() == Qt::Key_Enter){
        qDebug()<<"in KeyPressed QEvent::KeyPress"<<endl;
        if( ui -> userName_le -> hasFocus() ){
            if( ui -> checkExist_btn -> hasFocus()){
                if(ui -> ans_le -> hasFocus()){
                    judgeEmpty();
                }
                else{
                    ui -> ans_le -> setFocus();
                }
            }
            else{
                ui -> checkExist_btn -> setFocus();
            }
        }
        else{
            ui -> userName_le -> setFocus();
        }
    }*/
}
//new end

void Getbackpwd::cancelToMain(){
    LogInWindow *log = new LogInWindow;
    log ->show();
    close();
}

void Getbackpwd::on_checkExist_btn_clicked()
{
    userNameGet = ui -> userName_le -> text();
    if(userNameGet.isEmpty()){
        QMessageBox::warning(this, tr("警告"),tr("输入为空！"),tr("关闭"));
        return;
    }

    QJsonObject simp_ayjson;
    simp_ayjson.insert("OPERATION", 11);
    simp_ayjson.insert("USERNAME", userNameGet);
    QJsonDocument document;
    document.setObject(simp_ayjson);
    QByteArray simpbyte_array = document.toJson(QJsonDocument::Compact);

    client->write(simpbyte_array);

    connect(client, &QTcpSocket::readyRead, [=]() {
        QByteArray array= client->readAll();

        // read json
        QJsonObject rootObj;
        rootObj = read(array);

        QString flag = rootObj.value("STATE").toString();

        QString userQuesReal = rootObj.value("QUESTION").toString();

        QString userAnsReal = rootObj.value("ANSWER").toString();

        QString passWordReal = rootObj.value("PASSWORD").toString();

        qDebug() << flag << userQuesReal << userAnsReal << passWordReal;


        if(flag == "allow"){
            ui->quesGet_lb->setText(userQuesReal);
           judgeRight(userAnsReal,passWordReal);
        }
        else{
            QMessageBox::warning(this, tr("警告"),tr("用户名不存在！"),tr("关闭"));
        }
      });



    client->flush();
}

QJsonObject Getbackpwd::read(QByteArray buffer){
    QJsonParseError json_error;
    QJsonDocument jsonDoc(QJsonDocument::fromJson(buffer, &json_error));
    if(json_error.error != QJsonParseError::NoError)
    {
        qDebug() << "json error!";
    }
    QJsonObject rootObj = jsonDoc.object();
    return rootObj;
}

void Getbackpwd::judgeRight(QString userAnsReal,QString passWordReal){;
    userAnsRight = userAnsReal;
    userPasswordRight = passWordReal;
}
void Getbackpwd::on_yes_btn_clicked()
{
    userAnsGet = ui->ans_le->text();
    if(userAnsGet.isEmpty()){
        QMessageBox::warning(this, tr("警告"),tr("输入为空！"),tr("关闭"));
    }
    else{
        if(userAnsGet == userAnsRight){
            QMessageBox::warning(this, tr(""),tr("你的密码是：")+ userPasswordRight,tr("关闭"));
            MainWindow *mainWindow = new MainWindow;
            mainWindow ->show();
        }
        else{
            QMessageBox::warning(this, tr("警告"),tr("输入错误！"),tr("关闭"));
        }
    }
}
