#include "receiveletterbox.h"
#include "ui_receiveletterbox.h"
#include "ReceiveLetterDetail.h"

ReceiveLetterBox::ReceiveLetterBox(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::ReceiveLetterBox)
{
    ui->setupUi(this);
    receiveTableBuild();
}

ReceiveLetterBox::~ReceiveLetterBox()
{
    delete ui;
}

void ReceiveLetterBox::receiveTableBuild(){
    standItemModel = new QStandardItemModel();//添加QTableView代码
    //添加表头
    standItemModel->setColumnCount(6);
    standItemModel->setHeaderData(0,Qt::Horizontal,QStringLiteral("发件人"));   //设置表头内容
    standItemModel->setHeaderData(1,Qt::Horizontal,QStringLiteral("收件人"));
    standItemModel->setHeaderData(2,Qt::Horizontal,QStringLiteral("抄送人"));
    standItemModel->setHeaderData(3,Qt::Horizontal,QStringLiteral("密送人"));
    standItemModel->setHeaderData(4,Qt::Horizontal,QStringLiteral("主题"));
    standItemModel->setHeaderData(5,Qt::Horizontal,QStringLiteral("内容"));

    int temp=0;
    while(!receiveLetter[temp][7].isEmpty()){
         temp++;
    }
    receiveLetterCount = temp;

    //向表格添加10行内容，用以展示，可以将此内容看作test效果
    for(int i=0;i< receiveLetterCount;i++){
        //以下为头checkbox功能
        for(int j=0;j<8;j++){
            standItemModel->setItem(i,j,new QStandardItem(receiveLetter[i][j]));   //表格第i行，第2列添加一项内容
            standItemModel->item(i,j)->setTextAlignment(Qt::AlignCenter);
        }
    }


    ui -> tableView->setModel(standItemModel);    //挂载表格模型
    //设定表格的宽度

    //以下内容为表格格式
    ui -> tableView->horizontalHeader()->setSectionResizeMode(0,QHeaderView::Fixed);  //设定序号和收发栏列宽不可变
    ui -> tableView->horizontalHeader()->setSectionResizeMode(4,QHeaderView::Fixed);
    ui -> tableView->horizontalHeader()->setSectionResizeMode(5,QHeaderView::Stretch);//设定主题弹性拉伸


    ui -> tableView->verticalHeader()->hide();    //隐藏默认显示的行头
    ui -> tableView->hideColumn(1);  //隐藏时间戳列表
    ui -> tableView->hideColumn(2);  //隐藏时间戳列表
    ui -> tableView->hideColumn(3);  //隐藏时间戳列表
    ui -> tableView->hideColumn(6);
    ui -> tableView->hideColumn(7);


    ui -> tableView->setSelectionBehavior(QAbstractItemView::SelectRows); //设置选中时整行选中
    ui -> tableView->setEditTriggers(QAbstractItemView::NoEditTriggers);  //设置表格属性只读，不能编辑
    ui -> tableView->setAlternatingRowColors(true);  // alternative colors
    ui -> tableView->sortByColumn(7,Qt::AscendingOrder);                 //按照时间戳降序排列，也就是最后收到的排在最开头

    ui -> tableView->setContextMenuPolicy(Qt::CustomContextMenu);         //右键弹出菜单功能
    //以下为右键弹出菜单功能
    rightClickMenu = new QMenu();               //右键点击菜单
    deleteAction = new QAction(QString::fromLocal8Bit("delete"),this);               //删除or移动事件
    rightClickMenu->addAction(deleteAction);    //将action添加到菜单内
    connect(ui-> tableView, SIGNAL(customContextMenuRequested(QPoint)), this, SLOT(rithtClickMenu(QPoint)));
    connect(rightClickMenu, SIGNAL(triggered(QAction*)), this, SLOT(menuChooseAction(QAction*)));

}

void ReceiveLetterBox::rithtClickMenu(QPoint pos){
    QModelIndex index = ui -> tableView -> indexAt(pos);    //找到tableview当前位置信息
    if(index.isValid()){        //如果行数有效，则显示菜单
        rightClickMenu->exec(QCursor::pos());
    }
}

void ReceiveLetterBox::menuChooseAction(QAction *act){  //弹出提示框，看是否删除数据
    QMessageBox message(
                QMessageBox::NoIcon, QString::fromLocal8Bit("Warn"),
                QString::fromLocal8Bit("This Mail will be moved"),
                QMessageBox::Yes | QMessageBox::No, NULL);
}

void ReceiveLetterBox::on_tableView_doubleClicked(const QModelIndex &index)
{
    if(index.isValid()){        //如果行数有效，则显示detail
        qDebug() <<""<< endl;
        readLine = index.row();
        receiveLetterDetail = new ReceiveLetterDetail;
        receiveLetterDetail -> show();
    }
}
