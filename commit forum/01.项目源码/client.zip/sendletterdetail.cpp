#include "sendletterdetail.h"
#include "ui_sendletterdetail.h"


SendLetterDetail::SendLetterDetail(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::SendLetterDetail)
{
    ui->setupUi(this);
    initSet();

    QString IP = "192.168.43.11";
    int port = 8765;

    client = new QTcpSocket();

    //取消已有的连接
    client->abort();

    //连接服务器
    client->connectToHost(IP, port);

    //等待连接成功
    if(!client->waitForConnected(30000))
    {
        qDebug() << "Connection failed!";
        return;
    }
}

SendLetterDetail::~SendLetterDetail()
{
    delete ui;
}

void SendLetterDetail::initSet(){
    allText_btn = this -> findChildren<QPushButton*>();
    for(int i = 0;i < buttonNum ;i++){
         allText_btn[i]->setStyleSheet( fontColorArgb+buttonBackCol );
         allText_btn[i]->setFont( fontType );
    }

    allText_lb = this -> findChildren<QLabel*>();
    for(int i = 0 ;i < labelNum ;i++){
         allText_lb[i] -> setStyleSheet( fontColorArgb );
         allText_lb[i] -> setFont( fontType );
    }
    allText_te = this -> findChildren<QTextEdit*>();
    for(int i = 0 ;i < textEditNum ;i++){
         allText_te[i] -> setStyleSheet( fontColorArgb );
         allText_te[i] -> setFont( fontType );
    }

    this -> setStyleSheet( backGroundColor );
//new
    qDebug()<<"sendLetter[readLine]"<<sendLetter[readLine][1];
    ui ->Lreceiver -> setText( sendLetter[readLine][1]);
    ui ->LreceivOther -> setText( sendLetter[readLine][2]);
    ui ->LreceiverSecert -> setText( sendLetter[readLine][3]);
    ui ->LthemInput -> setText( sendLetter[readLine][4]);
    ui ->Lcontext -> setText( sendLetter[readLine][5]);

    ui ->Lreceiver ->setReadOnly(true);
    ui ->LreceivOther ->setReadOnly(true);
    ui ->LreceiverSecert ->setReadOnly(true);
    ui ->LthemInput ->setReadOnly(true);
    ui ->Lcontext ->setReadOnly(true);

}

void SendLetterDetail::on_Ldelete_clicked()
{
    //删除槽函数
    QMessageBox::StandardButton result=QMessageBox::question(this, "确认", "确定要删除吗？",QMessageBox::Yes|QMessageBox::No,QMessageBox::No);
    if (result == QMessageBox::Yes){

         //如果点击了确认删除，则删除
        QJsonObject simp_ayjson;
        simp_ayjson.insert("OPERATION", 10);
        simp_ayjson.insert("AUDIENCE", userNameRight);
        simp_ayjson.insert("TITLE", sendLetter[readLine][4]);

        qDebug()<<"1:"<<userNameRight;
        qDebug()<<"2:"<<sendLetter[readLine][4];
        QJsonDocument document;
        document.setObject(simp_ayjson);
        QByteArray simpbyte_array = document.toJson(QJsonDocument::Compact);

        client->write(simpbyte_array);


        qDebug()<<"delete ok";

        client->flush();


        QString title = sendLetter[readLine][4];
        qDebug()<<"title:"<<title;
        //删除结束后
        QMessageBox::question(this, "关闭", "删除成功！");
        close();
     }
     else{
          //否则取消
     }
}
