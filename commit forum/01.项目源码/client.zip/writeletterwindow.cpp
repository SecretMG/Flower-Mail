#include "writeletterwindow.h"
#include "ui_writeletterwindow.h"

#include "contecterlistwindow.h"
#include "addattachwindows.h"
#include "mainwindow.h"

#include <QDebug>
#include <QFontDialog>
#include <QColorDialog>
#include <QLineEdit>
#include <QKeyEvent>

int isFinish = 0;
QString isDoc = "0";

QByteArray simpbyte_array;

WriteLetterWindow::WriteLetterWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::WriteLetterWindow)
{
    ui->setupUi(this);
    setWindowTitle("编辑邮件");
    setConnect();
    initSet();
    extern QString backGroundColor;
    this -> setStyleSheet(backGroundColor);

    m_payloadSize=64*1024;
    m_totalBytes=0;
    m_bytesWritten=0;
    m_bytesToWrite=0;

    client = new QTcpSocket();
    fileTrans = new QTcpSocket();

    QString IP = "192.168.43.11";
    int port = 8765;

    //取消已有的连接
    client->abort();

    //连接服务器
    client->connectToHost(IP, port);

    //等待连接成功
    if(!client->waitForConnected(30000))
    {
        qDebug() << "Connection failed!";
        return;
    }

    connect(fileTrans,SIGNAL(connected()),this,SLOT(startTransfer()));
    connect(fileTrans,SIGNAL(bytesWritten(qint64)),this,SLOT(updateClientProgress(qint64)));
}

WriteLetterWindow::~WriteLetterWindow()
{
    delete ui;
}

void WriteLetterWindow::openFile(){
    isDoc = "1";
    m_fileName=QFileDialog::getOpenFileName(this);
    if(!m_fileName.isEmpty()){
        ui->UPloadattach->setEnabled(true);
        ui->clientStatusLabel->setText(QString("已选取: %1 ").arg(m_fileName));
    }
}

void WriteLetterWindow::send(){
    ui->UPloadattach->setEnabled(false);
    m_bytesWritten=0;
    fileTrans->connectToHost("192.168.43.11",8765);

}

void WriteLetterWindow::startTransfer(){

    if(isDoc == "1"){
    m_localFile=new QFile(m_fileName);
    if(!m_localFile->open(QFile::ReadOnly)){
        qDebug()<<"client：open file error!";
        return;
    }
    m_totalBytes=m_localFile->size();
    QDataStream sendOut(&m_outBlock,QIODevice::WriteOnly);
    sendOut.setVersion(QDataStream::Qt_5_7);
    QString currentFileName=m_fileName.right(m_fileName.size()-m_fileName.lastIndexOf('/')-1);
    //文件总大小、文件名大小、文件名
    sendOut<<qint64(0)<<qint64(0)<<currentFileName;
    m_totalBytes+=m_outBlock.size();
    sendOut.device()->seek(0);
    sendOut<<m_totalBytes<<qint64(m_outBlock.size()-sizeof(qint64)*2);
    m_bytesToWrite=m_totalBytes-fileTrans->write(m_outBlock);
    m_outBlock.resize(0);

    }
}

void WriteLetterWindow::updateClientProgress(qint64 numBytes){
    if(isDoc == "1"){
    m_bytesWritten+=(int)numBytes;
    if(m_bytesToWrite>0){
        m_outBlock=m_localFile->read(qMin(m_bytesToWrite,m_payloadSize));
        m_bytesToWrite-=(int)fileTrans->write(m_outBlock);

        m_outBlock.resize(0);
    }
    else{
        m_localFile->close();
    }

    if(m_bytesWritten==m_totalBytes){
        m_localFile->close();

        fileTrans->close();
        qDebug()<<"???";
    }

  }
}

void WriteLetterWindow::openContactor(){
    qDebug() <<"openContactor"<< endl;
    contecterListwindow = new ContecterListwindow;
    contecterListwindow -> show();
}

void WriteLetterWindow::setConnect(){
    //connect( ui -> ReceiveListButton, SIGNAL(clicked()), this, SLOT( openContactor()) );
    connect (ui -> LchooseFont, SIGNAL(clicked()), this, SLOT( openFontSet()) );
    connect (ui -> LchooseFontColor, SIGNAL(clicked()), this, SLOT( openFontColor()) );
    connect (ui -> Lsend, SIGNAL(clicked()), this, SLOT( judgeRight()) );

    connect(ui -> Lreceiver, SIGNAL(sendSenderData(QString)), this, SLOT(receiveSenderData(QString)));
    connect(ui -> LthemInput, SIGNAL(sendThemeData(QString)), this, SLOT(receiveThemeData(QString)));
    connect(ui -> Lcontext, SIGNAL(sendContextData(QString)), this, SLOT(receiveContextData(QString)));

}

void WriteLetterWindow::initSet(){
    allText_btn = this -> findChildren<QPushButton*>();
    for(int i = 0;i < buttonNum ;i++){
         allText_btn[i]->setStyleSheet( fontColorArgb+buttonBackCol );
         allText_btn[i]->setFont( fontType );
    }

    allText_lb = this -> findChildren<QLabel*>();
    for(int i = 0 ;i < labelNum ;i++){
         allText_lb[i] -> setStyleSheet( fontColorArgb );
         allText_lb[i] -> setFont( fontType );
    }
    allText_te = this -> findChildren<QTextEdit*>();
    for(int i = 0 ;i < textEditNum ;i++){
         allText_te[i] -> setStyleSheet( fontColorArgb );
         allText_te[i] -> setFont( fontType );
    }
    allText_le = this -> findChildren<QLineEdit*>();
    for(int i = 0 ;i < lineEditNum ;i++){
         allText_le[i] -> setStyleSheet( fontColorArgb );
         allText_le[i] -> setFont( fontType );
    }
    ui->sendFile_btn->setVisible(false);
    //1表示点击回复，2表示点击转发

    qDebug()<<"receiveLetterState"<<receiveLetterState;
    if(receiveLetterState == 1){
        //0-5对应发件人/收件人/密送人/抄送人/主题/邮件详情
        ui->Lreceiver->setText(receiveLetter[readLine][0]);
        QString beforeTheme = "RE:";
        beforeTheme.append(receiveLetter[readLine][4]);
        ui->LthemInput->setText(beforeTheme);
        ui->Lcontext->setText(receiveLetter[readLine][5]);

    }else if(receiveLetterState == 2){
        QString beforeTheme = "FW:";
        beforeTheme.append(receiveLetter[readLine][4]);
        ui->LthemInput->setText(beforeTheme);
        ui->Lcontext->setText(receiveLetter[readLine][5]);

    }
    receiveLetterState = 0;

}

void WriteLetterWindow::openFontSet(){
    bool *isfontType = new bool();
    textFont = QFontDialog::getFont( isfontType , this);
    changeFont();
    delete isfontType;
}

void WriteLetterWindow::openFontColor(){
    textColor = QColorDialog::getColor(lastColor, this,tr("颜色对话框"),QColorDialog::ShowAlphaChannel);
    qDebug() << "choose font color" << textColor << endl;
    changeColor();
    lastColor = textColor;
}

void WriteLetterWindow::changeFont(){

    for(int i = 0;i < textEditNum; i++){
        allText_te[i] -> setFont( textFont );
    }
}

void WriteLetterWindow::changeColor(){
    for(int i = 0;i < textEditNum; i++){
        allText_te[i] -> setStyleSheet( fontColorArgb );
    }
}

void WriteLetterWindow::judgeRight(){
    QString content = ui -> Lcontext->toPlainText();
    if(content.contains(QRegExp("[a-zA-Z0-9 -/:-?]"))){
       judgeEmpty();
    }
    else{
        QMessageBox::warning(this, tr("警告"),tr("输入包括中文字符或为空！"),tr("关闭"));
    }
}

void WriteLetterWindow::judgeEmpty(){
    receivePerson = ui->Lreceiver -> text();
    copyPerson = ui ->LreceivOther ->text();
    secretSendPerson = ui -> LreceiverSecert -> text();
    theme = ui -> LthemInput -> text();
    if( receivePerson.isEmpty() || theme.isEmpty()){
        QMessageBox::warning(this, tr("警告"),tr("输入为空！"),tr("关闭"));
    }

}

void WriteLetterWindow::json(){
    int count = 1;
    int last = 0;
    QString receiver[ 6 ] ;
    QString getRec = ui ->Lreceiver -> text() +";";
    for(int i = 0;i<getRec.length();i++){
        if(getRec[i] == ';'&& count < 6){
            receiver[ count++ ] = getRec.mid( last , i-last );
            last = i + 1;
            qDebug()<<"string of receiver:"<<count-1<<":"<<receiver[ count-1 ]<<endl;
        }
    }

    count = 1;
    last = 0;
    QString receiverSecret[ 6 ];
    QString getSec = ui ->LreceiverSecert -> text() +";";
    for(int i = 0;i<getSec.length();i++){
        if(getSec[i] == ';'&& count < 6){
            receiverSecret[ count++ ] = getSec.mid( last , i-last );
            last = i + 1;
            qDebug()<<"string of receiverSecret:"<<count-1<<":"<<receiverSecret[ count-1 ]<<endl;
        }
    }

    count = 1;
    last = 0;
    QString receiverCopy[ 6 ];
    QString getCopy = ui ->LreceivOther -> text() +";";
    for(int i = 0;i<getCopy.length();i++){
        if(getCopy[i] == ';'&& count < 6){
            receiverCopy[ count++ ] = getCopy.mid( last , i-last );
            last = i + 1;
            qDebug()<<"string of receiverCopy:"<<count-1<<":"<<receiverCopy[ count-1 ]<<endl;
        }
    }

    QString theme = ui -> LthemInput -> text();
    QString content = ui -> Lcontext-> toPlainText();

    QJsonObject simp_ayjson;
    simp_ayjson.insert("OPERATION", 7);
    simp_ayjson.insert("SENDER", userNameRight);

    int flag = 0;
    for(int i = 1;i < 6;i++){
        if(!receiver[i].isEmpty())
            flag++;
        else
            break;
    }
    qDebug()<<"recv:"<<flag;
    switch (flag) {
    case 1:simp_ayjson.insert("RECEIVER1", receiver[1]);
        simp_ayjson.insert("RECEIVER2", "");
        simp_ayjson.insert("RECEIVER3", "");
        simp_ayjson.insert("RECEIVER4", "");
        simp_ayjson.insert("RECEIVER5", "");break;

    case 2:simp_ayjson.insert("RECEIVER1", receiver[1]);
        simp_ayjson.insert("RECEIVER2", receiver[2]);
        simp_ayjson.insert("RECEIVER3", "");
        simp_ayjson.insert("RECEIVER4", "");
        simp_ayjson.insert("RECEIVER5", "");break;

    case 3:simp_ayjson.insert("RECEIVER1", receiver[1]);
        simp_ayjson.insert("RECEIVER2", receiver[2]);
        simp_ayjson.insert("RECEIVER3", receiver[3]);
        simp_ayjson.insert("RECEIVER4", "");
        simp_ayjson.insert("RECEIVER5", "");break;

    case 4:simp_ayjson.insert("RECEIVER1", receiver[1]);
        simp_ayjson.insert("RECEIVER2", receiver[2]);
        simp_ayjson.insert("RECEIVER3", receiver[3]);
        simp_ayjson.insert("RECEIVER4", receiver[4]);
        simp_ayjson.insert("RECEIVER5", "");break;

    case 5:simp_ayjson.insert("RECEIVER1", receiver[1]);
           simp_ayjson.insert("RECEIVER2", receiver[2]);
           simp_ayjson.insert("RECEIVER3", receiver[3]);
           simp_ayjson.insert("RECEIVER4", receiver[4]);
           simp_ayjson.insert("RECEIVER5", receiver[5]);break;
    }

    flag = 0;
    for(int i = 1;i < 6;i++){
        if(!receiverCopy[i].isEmpty())
            flag++;
        else
            break;
    }
    qDebug()<<"copy:"<<flag;
    switch (flag) {
    case 0:simp_ayjson.insert("COPYTO1", "");
        simp_ayjson.insert("COPYTO2", "");
        simp_ayjson.insert("COPYTO3", "");
        simp_ayjson.insert("COPYTO4","");
        simp_ayjson.insert("COPYTO5","");break;


    case 1:simp_ayjson.insert("COPYTO1", receiverCopy[1]);
        simp_ayjson.insert("COPYTO2", "");
        simp_ayjson.insert("COPYTO3", "");
        simp_ayjson.insert("COPYTO4", "");
        simp_ayjson.insert("COPYTO5", "");break;

    case 2:simp_ayjson.insert("COPYTO1", receiverCopy[1]);
        simp_ayjson.insert("COPYTO2", receiverCopy[2]);
        simp_ayjson.insert("COPYTO3", "");
        simp_ayjson.insert("COPYTO4", "");
        simp_ayjson.insert("COPYTO5", "");break;

    case 3:simp_ayjson.insert("COPYTO1", receiverCopy[1]);
        simp_ayjson.insert("COPYTO2", receiverCopy[2]);
        simp_ayjson.insert("COPYTO3", receiverCopy[3]);
        simp_ayjson.insert("COPYTO4", "");
        simp_ayjson.insert("COPYTO5", "");break;

    case 4:simp_ayjson.insert("COPYTO1", receiverCopy[1]);
        simp_ayjson.insert("COPYTO2", receiverCopy[2]);
        simp_ayjson.insert("COPYTO3", receiverCopy[3]);
        simp_ayjson.insert("COPYTO4", receiverCopy[4]);
        simp_ayjson.insert("COPYTO5", "");break;

    case 5:simp_ayjson.insert("COPYTO1", receiverCopy[1]);
           simp_ayjson.insert("COPYTO2", receiverCopy[2]);
           simp_ayjson.insert("COPYTO3", receiverCopy[3]);
           simp_ayjson.insert("COPYTO4", receiverCopy[4]);
           simp_ayjson.insert("COPYTO5", receiverCopy[5]);break;
   }

    flag = 0;
    for(int i = 1;i < 6;i++){
        if(!receiverSecret[i].isEmpty())
             flag++;
        else
             break;
    }
    switch (flag) {
    case 0:simp_ayjson.insert("SECRET1", "");
        simp_ayjson.insert("SECRET2", "");
        simp_ayjson.insert("SECRET3", "");
        simp_ayjson.insert("SECRET4", "");
        simp_ayjson.insert("SECRET5", "");break;


    case 1:simp_ayjson.insert("SECRET1", receiverSecret[1]);
        simp_ayjson.insert("SECRET2", "");
        simp_ayjson.insert("SECRET3", "");
        simp_ayjson.insert("SECRET4", "");
        simp_ayjson.insert("SECRET5", "");break;

    case 2:simp_ayjson.insert("SECRET1", receiverSecret[1]);
        simp_ayjson.insert("SECRET2", receiverSecret[2]);
        simp_ayjson.insert("SECRET3", "");
        simp_ayjson.insert("SECRET4", "");
        simp_ayjson.insert("SECRET5", "");break;

    case 3:simp_ayjson.insert("SECRET1", receiverSecret[1]);
        simp_ayjson.insert("SECRET2", receiverSecret[2]);
        simp_ayjson.insert("SECRET3", receiverSecret[3]);
        simp_ayjson.insert("SECRET4", "");
        simp_ayjson.insert("SECRET5", "");break;

    case 4:simp_ayjson.insert("SECRET1", receiverSecret[1]);
        simp_ayjson.insert("SECRET2", receiverSecret[2]);
        simp_ayjson.insert("SECRET3", receiverSecret[3]);
        simp_ayjson.insert("SECRET4", receiverSecret[4]);
        simp_ayjson.insert("SECRET5", "");break;

    case 5:simp_ayjson.insert("SECRET1", receiverSecret[1]);
           simp_ayjson.insert("SECRET2", receiverSecret[2]);
           simp_ayjson.insert("SECRET3", receiverSecret[3]);
           simp_ayjson.insert("SECRET4", receiverSecret[4]);
           simp_ayjson.insert("SECRET5", receiverSecret[5]);break;
    }
    simp_ayjson.insert("TITLE", theme);
    qDebug()<<theme;
    simp_ayjson.insert("TEXT", content);

    simp_ayjson.insert("FILE", isDoc);

    QJsonDocument document;
    document.setObject(simp_ayjson);
    simpbyte_array = document.toJson(QJsonDocument::Compact);


    client->write(simpbyte_array);

    connect(client, &QTcpSocket::readyRead, [=]() {
      QByteArray array= client->readAll();
      QString array1=array;
      qDebug()<<array1;

     });

    client->flush();
}

void WriteLetterWindow::on_Lsend_clicked(){

    json();
    ui->sendFile_btn->setVisible(true);
    if(!ui->Lreciver->text().isEmpty() &&!ui->LthemInput->text().isEmpty()){
        if(isDoc == '0' ){
            QMessageBox::information(NULL, "提示", "发送成功！");
            close();
        }

    }
    else{
        QMessageBox::warning(this, tr("警告"),tr("输入为空!"),tr("确定"));
        return;
    }
}

void WriteLetterWindow::on_SaveDraftButton_clicked()
{
    int count = 1;
    int last = 0;
    QString receiver[ 6 ];
    QString getRec = ui ->Lreceiver -> text() +";";
    for(int i = 0;i<getRec.length();i++){
        if(getRec[i] == ';'&& count < 6){
            receiver[ count++ ] = getRec.mid( last , i-last );
            last = i + 1;
            qDebug()<<"string of receiver:"<<count-1<<":"<<receiver[ count-1 ]<<endl;
        }
    }

    count = 1;
    last = 0;
    QString receiverSecret[ 6 ];
    QString getSec = ui ->LreceiverSecert -> text() +";";
    for(int i = 0;i<getSec.length();i++){
        if(getSec[i] == ';'&& count < 6){
            receiverSecret[ count++ ] = getSec.mid( last , i-last );
            last = i + 1;
            qDebug()<<"string of receiverSecret:"<<count-1<<":"<<receiverSecret[ count-1 ]<<endl;
        }
    }

    count = 1;
    last = 0;
    QString receiverCopy[ 6 ];
    QString getCopy = ui ->LreceivOther -> text() +";";
    for(int i = 0;i<getCopy.length();i++){
        if(getCopy[i] == ';'&& count < 6){
            receiverCopy[ count++ ] = getCopy.mid( last , i-last );
            last = i + 1;
            qDebug()<<"string of receiverCopy:"<<count-1<<":"<<receiverCopy[ count-1 ]<<endl;
        }
    }

    QString theme = ui -> LthemInput -> text();
    QString content = ui -> Lcontext-> toPlainText();

    QJsonObject simp_ayjson;
    simp_ayjson.insert("OPERATION", 9);
    simp_ayjson.insert("SENDER", userNameRight);

    int flag = 0;
    for(int i = 1;i < 6;i++){
        if(!receiver[i].isEmpty())
            flag++;
        else
            break;
    }
    switch (flag) {
    case 1:simp_ayjson.insert("RECEIVER1", receiver[1]);break;

    case 2:simp_ayjson.insert("RECEIVER1", receiver[1]);
           simp_ayjson.insert("RECEIVER2", receiver[2]);break;

    case 3:simp_ayjson.insert("RECEIVER1", receiver[1]);
           simp_ayjson.insert("RECEIVER2", receiver[2]);
           simp_ayjson.insert("RECEIVER3", receiver[3]);break;

    case 4:simp_ayjson.insert("RECEIVER1", receiver[1]);
           simp_ayjson.insert("RECEIVER2", receiver[2]);
           simp_ayjson.insert("RECEIVER3", receiver[3]);
           simp_ayjson.insert("RECEIVER4", receiver[4]);break;

    case 5:simp_ayjson.insert("RECEIVER1", receiver[1]);
           simp_ayjson.insert("RECEIVER2", receiver[2]);
           simp_ayjson.insert("RECEIVER3", receiver[3]);
           simp_ayjson.insert("RECEIVER4", receiver[4]);
           simp_ayjson.insert("RECEIVER5", receiver[5]);break;
    }

    flag = 0;
    for(int i = 1;i < 6;i++){
        if(!receiverCopy[i].isEmpty())
            flag++;
        else
            break;
    }
    switch (flag) {
    case 0:break;
    case 1:simp_ayjson.insert("COPYTO1", receiverCopy[1]);break;

    case 2:simp_ayjson.insert("COPYTO1", receiverCopy[1]);
           simp_ayjson.insert("COPYTO2", receiverCopy[2]);break;

    case 3:simp_ayjson.insert("COPYTO1", receiverCopy[1]);
           simp_ayjson.insert("COPYTO2", receiverCopy[2]);
           simp_ayjson.insert("COPYTO3", receiverCopy[3]);break;
        break;

    case 4:simp_ayjson.insert("COPYTO1", receiverCopy[1]);
           simp_ayjson.insert("COPYTO2", receiverCopy[2]);
           simp_ayjson.insert("COPYTO3", receiverCopy[3]);
           simp_ayjson.insert("COPYTO4", receiverCopy[4]);break;
        break;

    case 5:simp_ayjson.insert("COPYTO1", receiverCopy[1]);
           simp_ayjson.insert("COPYTO2", receiverCopy[2]);
           simp_ayjson.insert("COPYTO3", receiverCopy[3]);
           simp_ayjson.insert("COPYTO4", receiverCopy[4]);
           simp_ayjson.insert("COPYTO5", receiverCopy[5]);break;
   }

    flag = 0;
    for(int i = 1;i < 6;i++){
        if(!receiverSecret[i].isEmpty())
             flag++;
        else
             break;
    }
    switch (flag) {
    case 0:break;
    case 1:simp_ayjson.insert("SECRET1", receiverSecret[1]);break;

    case 2:simp_ayjson.insert("SECRET1", receiverSecret[1]);
           simp_ayjson.insert("SECRET2", receiverSecret[2]);break;

    case 3:simp_ayjson.insert("SECRET1", receiverSecret[1]);
           simp_ayjson.insert("SECRET2", receiverSecret[2]);
           simp_ayjson.insert("SECRET3", receiverSecret[3]);break;

    case 4:simp_ayjson.insert("SECRET1", receiverSecret[1]);
           simp_ayjson.insert("SECRET2", receiverSecret[2]);
           simp_ayjson.insert("SECRET3", receiverSecret[3]);
           simp_ayjson.insert("SECRET4", receiverSecret[4]);break;

    case 5:simp_ayjson.insert("SECRET1", receiverSecret[1]);
           simp_ayjson.insert("SECRET2", receiverSecret[2]);
           simp_ayjson.insert("SECRET3", receiverSecret[3]);
           simp_ayjson.insert("SECRET4", receiverSecret[4]);
           simp_ayjson.insert("SECRET5", receiverSecret[5]);break;
    }
    simp_ayjson.insert("TITLE", theme);
    simp_ayjson.insert("TEXT", content);

    QJsonDocument document;
    document.setObject(simp_ayjson);
    QByteArray simpbyte_array = document.toJson(QJsonDocument::Compact);

    client->write(simpbyte_array);

    connect(client, &QTcpSocket::readyRead, [=]() {
      QByteArray array= client->readAll();
      QString array1=array;
      qDebug()<<array1;

     });
    if(isFinish)
        client->flush();

    QMessageBox::information(NULL, "提示", "已存至草稿箱！请刷新邮箱界面！");
    this->close();
}

void WriteLetterWindow::on_UPloadattach_clicked()
{
    openFile();
}

void WriteLetterWindow::on_sendFile_btn_clicked()
{   
    send();
    if(isDoc == '1'){
        QMessageBox::information(NULL, "提示", "发送成功！");
        close();
    }
//    if(isFinish)
//        fileTrans->close();
}
