#ifndef SENDLETTERDETAIL_H
#define SENDLETTERDETAIL_H

#include <QWidget>
#include <QMainWindow>
#include <QTextEdit>
#include <QPushButton>
#include <QLabel>
#include <QtNetwork>
#include <QMessageBox>
#include <QDebug>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>

extern QFont fontType;
extern QString fontColorArgb;
extern QString buttonBackCol;
extern QString backGroundColor;

extern QString userNameRight;
extern QString sendLetter[100][8];
extern int readLine;

namespace Ui {
class SendLetterDetail;
}

class SendLetterDetail : public QWidget
{
    Q_OBJECT

public:
    explicit SendLetterDetail(QWidget *parent = nullptr);
    ~SendLetterDetail();

private slots:
    void on_Ldelete_clicked();

private:
    Ui::SendLetterDetail *ui;
    QList<QPushButton*> allText_btn;
    QList<QLabel*> allText_lb;
    QList<QTextEdit*> allText_te;
    const int labelNum = 4;
    const int buttonNum = 1;
    const int textEditNum = 5;

    QFont textFont;
    QColor textColor;
    QFont lastFont;
    QColor lastColor;

    QTcpSocket *client;

private:
    void initSet();
};

#endif // SENDLETTERDETAIL_H
