#include "DeleteLetterDetail.h"
#include "ui_DeleteLetterDetail.h"

#include <QDebug>
#include <QWidget>

DeleteLetterDetail::DeleteLetterDetail(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::DeleteLetterDetail)
{
    ui->setupUi(this);
    setWindowTitle("邮件详情");
    initSet();

    extern QString backGroundColor;
    this -> setStyleSheet(backGroundColor);
    ui -> sendSet_lb ->setText(deleteLetter[readLine][0]);
    ui -> receiSet_lb ->setText(deleteLetter[readLine][1]);
    ui -> copySet_lb ->setText(deleteLetter[readLine][2]);
    if(deleteLetter[ readLine ][ 0 ]==userNameRight){
        ui -> secretSet_lb ->setText(deleteLetter[readLine][3]);
    }
    ui -> titleSet_lb ->setText(deleteLetter[readLine][4]);
    ui -> LetterDetailsContext ->setText(deleteLetter[readLine][5]);
}

DeleteLetterDetail::~DeleteLetterDetail()
{
    delete ui;
}

void DeleteLetterDetail::initSet(){
    allText_lb = this -> findChildren<QLabel*>();
    for(int i = 0 ;i < labelNum ;i++){
         allText_lb[i] -> setStyleSheet( fontColorArgb );
         allText_lb[i] -> setFont( fontType );

    }
    allText_te = this -> findChildren<QTextEdit*>();
    for(int i = 0 ;i < textEditNum ;i++){
        allText_lb[i] -> setStyleSheet( fontColorArgb );
        allText_lb[i] -> setFont( fontType );
    }

    //数据库得到邮件详情
}
