#include "draftletterdetail.h"
#include "ui_draftletterdetail.h"

#include <QFontDialog>
#include <QColorDialog>


DraftLetterDetail::DraftLetterDetail(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::DraftLetterDetail)
{
    ui->setupUi(this);
    initSet();

    QString IP = "192.168.43.11";
    int port = 8765;
    client = new QTcpSocket();
    //取消已有的连接
    client->abort();
    //连接服务器
    client->connectToHost(IP, port);
    //等待连接成功
    if(!client->waitForConnected(30000))
    {
        qDebug() << "Connection failed!";
        return;
    }
}

DraftLetterDetail::~DraftLetterDetail()
{
    delete ui;
}

void DraftLetterDetail::on_Lsend_clicked()
{
    //发送槽函数
    if( ui->Lreceiver->toPlainText().isEmpty() || ui->LthemInput->toPlainText().isEmpty() ){
        QMessageBox::question(this, "关闭", "输入为空！");
        return;
    }

    QJsonObject simp_ayjson;
    simp_ayjson.insert("OPERATION", 8);
    simp_ayjson.insert("TITLE", ui->LthemInput->toPlainText());
    QJsonDocument document;
    document.setObject(simp_ayjson);
    QByteArray simpbyte_array = document.toJson(QJsonDocument::Compact);

    client->write(simpbyte_array);

    client->flush();

    //
    qDebug() << "Connect successfully!";
    qDebug() << "Send: " << "send something";

    QMessageBox::information(NULL, "提示", "发送成功！");
    close();


}

void DraftLetterDetail::on_LchooseFontColor_clicked()
{
    //改字体颜色
    textColor = QColorDialog::getColor(lastColor, this,tr("颜色对话框"),QColorDialog::ShowAlphaChannel);
    QString textColorString = QString("color:rgba(%1, %2, %3, %4);")
            .arg(textColor.red())
            .arg(textColor.green())
            .arg(textColor.blue())
            .arg(textColor.alpha());
    lastColor = textColor;
    for(int i = 0;i < textEditNum; i++){
        allText_te[i] -> setStyleSheet( textColorString );
    }
}

void DraftLetterDetail::on_LchooseFont_clicked()
{
    //改字形
    bool *isfontType = new bool();
    textFont = QFontDialog::getFont( isfontType , this);
    for(int i = 0;i < textEditNum; i++){
        allText_te[i] -> setFont( textFont );
    }
    delete isfontType;
}

void DraftLetterDetail::on_Ldelete_clicked()
{
    //删除槽函数
    QMessageBox::StandardButton result=QMessageBox::question(this, "确认", "确定要删除吗？",QMessageBox::Yes|QMessageBox::No,QMessageBox::No);
    if (result == QMessageBox::Yes){
         //如果点击了确认删除，则删除

        QMessageBox::question(this, "关闭", "删除成功！请手动刷新页面！");
        close();
     }
     else{
          //否则取消
        //close();
     }
}

void DraftLetterDetail::initSet(){
    allText_btn = this -> findChildren<QPushButton*>();
    for(int i = 0;i < buttonNum ;i++){
         allText_btn[i]->setStyleSheet( fontColorArgb+buttonBackCol );
         allText_btn[i]->setFont( fontType );
    }

    allText_lb = this -> findChildren<QLabel*>();
    for(int i = 0 ;i < labelNum ;i++){
         allText_lb[i] -> setStyleSheet( fontColorArgb );
         allText_lb[i] -> setFont( fontType );
    }
    allText_te = this -> findChildren<QTextEdit*>();
    for(int i = 0 ;i < textEditNum ;i++){
         allText_te[i] -> setStyleSheet( fontColorArgb );
         allText_te[i] -> setFont( fontType );
    }

    this -> setStyleSheet(backGroundColor);

    //0-5对应发件人/收件人/密送人/抄送人/主题/邮件详情
    ui ->Lreceiver -> setText(draftLetter[readLine][1]);//QString draftLetter[100][6];
    qDebug()<<"now setting 1"<<draftLetter[readLine][1];
    ui ->LreceiverSecert -> setText(draftLetter[readLine][3]);
    qDebug()<<"now setting 3"<<draftLetter[readLine][3];
    ui ->LreceivOther -> setText(draftLetter[readLine][2]);
    qDebug()<<"now setting 2"<<draftLetter[readLine][2];
    ui ->LthemInput -> setText(draftLetter[readLine][4]);
    qDebug()<<"now setting 4"<<draftLetter[readLine][4];
    ui ->Lcontext -> setText(draftLetter[readLine][5]);
    qDebug()<<"now setting 5"<<draftLetter[readLine][5];
    //draftLetter[readLine][6];
    //draftLetter[readLine][7];
}
