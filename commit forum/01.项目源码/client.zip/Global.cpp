#include "global.h"

#include <QDebug>

class Global{
public:

    QColor fontColor;
    QFont fontType;
    QColor buttonColor;
    QString buttonBackCol;
    QString fontColorArgb;
    QColor backColor;
    QString backGroundColor;
    int themeType = 0;

    QString userNameRight;
    QString userQuesRight;
    QString userAnsRight;
    QString userPasswordRight;

    QString receiveLetter[100][8];//0-5对应发件人/收件人/密送人/抄送人/主题/邮件详情
    QString sendLetter[100][8];
    QString draftLetter[100][8];
    QString deleteLetter[100][8];
    QString searchLetter[100][8];

    int readLine;
    int receiveLetterCount;
    int sendLetterCount;
    int draftLetterCount;
    int deleteLetterCount;
    int searchLetterCount;
    int boxState;
    int receiveLetterState = 0;//1表示点击回复，2表示点击转发



private:
    Global(){
        qDebug()<<"init Global"<<endl;

        fontColor.setNamedColor("black");
        fontType.setFamily("Courier New");
        fontType.setPointSize(15);

        buttonColor.setNamedColor("grey");

        backGroundColor = QString("background-color:rgba(214,214,214,255);");
        buttonBackCol = QString("background-color:rgba(204,204,204,255);");
        fontColorArgb =QString("color:rgba(0,0,0,255);");

        userNameRight = "默认名称";

    }


};
