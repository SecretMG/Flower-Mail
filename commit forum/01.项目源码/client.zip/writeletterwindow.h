#ifndef WRITELETTERWINDOW_H
#define WRITELETTERWINDOW_H

#include "contecterlistwindow.h"
#include "addattachwindows.h"
#include "settimewindow.h"

#include <QMainWindow>
#include <QLabel>
#include <QTextEdit>
#include <QWidget>
#include <QtNetwork>
#include <QMessageBox>
#include <QDebug>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
#include <QFileDialog>

extern QString userNameRight;

extern QPalette userColor;
extern QFont fontType;
extern QString fontColorArgb;
extern QString buttonBackCol;
extern int receiveLetterState;//0表示点击回复，1表示点击转发
extern QString receiveLetter[100][8];
extern int readLine;

namespace Ui {
class WriteLetterWindow;
}

class WriteLetterWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit WriteLetterWindow(QWidget *parent = nullptr);
    ~WriteLetterWindow();

private:
    Ui::WriteLetterWindow *ui;
    ContecterListwindow *contecterListwindow;
    AddAttachWindows *addAttachWindows;
    //SetTimeWindow *setTime;

    QFont textFont;
    QColor textColor;
    QFont lastFont;
    QColor lastColor;

    QList<QLabel*> allText_lb;
    QList<QPushButton*> allText_btn;
    QList<QTextEdit*> allText_te;
    QList<QLineEdit*> allText_le;
    const int labelNum = 6;
    const int buttonNum = 6;
    const int textEditNum = 1;
    const int lineEditNum = 4;

    QString receivePerson;
    QString copyPerson;
    QString secretSendPerson;
    QString theme;

    QFile *m_localFile;
    qint64 m_totalBytes;
    qint64 m_bytesWritten;
    qint64 m_bytesToWrite;
    qint64 m_payloadSize;
    QString m_fileName;
    QByteArray m_outBlock;


private slots:
    void openContactor();
    void openFontSet();
    void openFontColor();
    void judgeRight();
    void on_Lsend_clicked();

    void on_SaveDraftButton_clicked();

    void on_UPloadattach_clicked();

    void openFile();
    void send();
    void startTransfer();
    void updateClientProgress(qint64);

    void on_sendFile_btn_clicked();

private:
    void setConnect();
    void json();
    void initSet();
    void changeFont();
    void changeColor();
    void judgeEmpty();
    QTcpSocket *client;
    QTcpSocket *fileTrans;
};

#endif // WRITELETTERWINDOW_H
