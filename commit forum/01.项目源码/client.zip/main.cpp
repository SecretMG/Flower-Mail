#include "loginwindow.h"
#include "draftletterdetail.h"
#include "sendletterdetail.h"
#include "mainwindow.h"

#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    LogInWindow logInWindow;
    logInWindow.show();

    return a.exec();
}
