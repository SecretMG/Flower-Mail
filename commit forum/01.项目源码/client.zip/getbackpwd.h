#ifndef GETBACKPWD_H
#define GETBACKPWD_H

#include <QWidget>
#include <QDebug>

#include <QWidget>
#include <QtNetwork>
#include <QMessageBox>
#include <QDebug>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>

extern QString userNameRight;
extern QString userAnsRight;
extern QString userQuesRight;
extern QString userPasswordRight;

namespace Ui {
class Getbackpwd;
}

class Getbackpwd : public QWidget
{
    Q_OBJECT

public:
    explicit Getbackpwd(QWidget *parent = nullptr);
    ~Getbackpwd();

private:
    Ui::Getbackpwd *ui;
    QString userNameGet;
    QString userAnsGet;
    QString userAnsRight;

private slots:
    void keyPressEvent(QKeyEvent *event);
    void cancelToMain();
    QJsonObject read(QByteArray buffer);
    void on_checkExist_btn_clicked();
    void judgeRight(QString userAnsReal,QString passWordReal);

    void on_yes_btn_clicked();

private:

    QTcpSocket *client;
};

#endif // GETBACKPWD_H
