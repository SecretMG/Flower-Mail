#ifndef DELETELETTERDETAIL_H
#define DELETELETTERDETAIL_H

#include <QMainWindow>
#include <QTextEdit>
#include <QLabel>
#include <QWidget>

extern QFont fontType;
extern QString fontColorArgb;
extern QString buttonBackCol;

extern QString userNameRight;

extern QString deleteLetter[100][8];
extern int readLine;


namespace Ui {
class DeleteLetterDetail;
}

class DeleteLetterDetail : public QMainWindow
{
    Q_OBJECT

public:
    explicit DeleteLetterDetail(QWidget *parent = nullptr);
    ~DeleteLetterDetail();

private slots:
    //void on_LetterDetailsContext_cursorPositionChanged(int arg1, int arg2);

private:
    Ui::DeleteLetterDetail *ui;

    //QList<QPushButton*> allText_btn;
    QList<QLabel*> allText_lb;
    QList<QTextEdit*> allText_te;
    const int labelNum = 10;
    //const int buttonNum = 4;
    const int textEditNum = 1;

private:
    void initSet();
};

#endif // DELETELETTERDETAIL_H
