#ifndef DETELELETTERBOX_H
#define DETELELETTERBOX_H

#include <QWidget>
#include <QLabel>
#include <QTableView>
#include <QHeaderView>
#include <QMenu>
#include <QAction>
#include <QMessageBox>
#include <QStandardItem>
#include <QStandardItemModel>
#include <QDebug>
#include "DeleteLetterDetail.h"

namespace Ui {
class DeleteLetterBox;
}

class DeleteLetterBox : public QWidget
{
    Q_OBJECT

public:
    explicit DeleteLetterBox(QWidget *parent = nullptr);
    void deleteTableBuild();
    ~DeleteLetterBox();

private:
    Ui::DeleteLetterBox *ui;
    QStandardItemModel    *standItemModel;
    DeleteLetterDetail    *deleteLetterDetail;



private slots:
    void on_tableView_doubleClicked(const QModelIndex &index);
};

#endif // DETELELETTERBOX_H
