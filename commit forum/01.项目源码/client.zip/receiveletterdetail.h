#ifndef RECEIVELETTERDETAIL_H
#define RECEIVELETTERDETAIL_H

#include "writeletterwindow.h"
#include "saveattach.h"

#include <QWidget>
#include <QMainWindow>
#include <QTextEdit>
#include <QPushButton>
#include <QLabel>
#include <QtNetwork>
#include <QMessageBox>
#include <QDebug>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>

extern QFont fontType;
extern QString fontColorArgb;
extern QString buttonBackCol;
extern QString backGroundColor;

extern QString userNameRight;
extern QString receiveLetter[100][8];
extern int receiveLetterState;//0表示点击回复，1表示点击转发
extern int readLine;


namespace Ui {
class ReceiveLetterDetail;
}

class ReceiveLetterDetail : public QMainWindow
{
    Q_OBJECT

public:
    explicit ReceiveLetterDetail(QWidget *parent = nullptr);
    ~ReceiveLetterDetail();

private:
    Ui::ReceiveLetterDetail *ui;
    WriteLetterWindow *replyWindow;
    WriteLetterWindow *forwardWindow;
    SaveAttach *saveAttach;

    QList<QPushButton*> allText_btn;
    QList<QLabel*> allText_lb;
    QList<QTextEdit*> allText_te;
    const int labelNum = 4;
    const int buttonNum = 4;
    const int textEditNum = 4;

    QString sendPer;
    QString receiPer;
    QString copyPer;
    QString title;
    QTcpSocket *client;

private slots:
    void openSaveAttach();
    void on_delete_btn_clicked();
    void on_ReplyB_clicked();
    void on_SaveAttachB_clicked();
    void on_ForwardB_clicked();

private:
    void setConnect();
    void initSet();
    qint64 totalBytes=0;  //存放总大小信息
    qint64 bytesReceived=0;  //已收到数据的大小
    qint64 fileNameSize=0;  //文件名的大小信息
    QString fileName;   //存放文件名
    QFile *localFile;   //本地文件
    QByteArray inBlock;   //数据缓冲区

};

#endif // RECEIVELETTERDETAIL_H
