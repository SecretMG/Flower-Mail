#include "sendletterbox.h"
#include "ui_sendletterbox.h"
#include "sendletterdetail.h"

SendLetterBox::SendLetterBox(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::SendLetterBox)
{
    ui->setupUi(this);
    qDebug()<<sendLetterCount;
    tableBuild();
}

SendLetterBox::~SendLetterBox()
{
    delete ui;
}

void SendLetterBox::tableBuild(){ //设定信箱分类；默认收件箱=1，已发送=2，草稿=3，垃圾=4，未读=5,此处需要与后端链接，也需要一个信箱点击为1-5的输入确定收取内容和表格
    standItemModel = new QStandardItemModel();//添加QTableView代码
    //添加表头

    standItemModel->setColumnCount(8);
    standItemModel->setHeaderData(0,Qt::Horizontal,QStringLiteral("发件人"));   //设置表头内容
    standItemModel->setHeaderData(1,Qt::Horizontal,QStringLiteral("收件人"));
    standItemModel->setHeaderData(2,Qt::Horizontal,QStringLiteral("抄送人"));
    standItemModel->setHeaderData(3,Qt::Horizontal,QStringLiteral("密送人"));
    standItemModel->setHeaderData(4,Qt::Horizontal,QStringLiteral("主题"));
    standItemModel->setHeaderData(5,Qt::Horizontal,QStringLiteral("内容"));
    standItemModel->setHeaderData(6,Qt::Horizontal,QStringLiteral("类型"));
    standItemModel->setHeaderData(7,Qt::Horizontal,QStringLiteral("类型"));
    int temp=0;
    while(!sendLetter[temp][7].isEmpty()){
         temp++;
    }
    sendLetterCount = temp;
    qDebug()<<"sendLetterCount in sendBox"<<sendLetterCount;
    for(int i=0;i< sendLetterCount;i++){
        for(int j = 0;j<7;j++){
            standItemModel->setItem(i,j,new QStandardItem(sendLetter[i][j]));   //表格第i行，第2列添加一项内容
            standItemModel->item(i,j)->setTextAlignment(Qt::AlignCenter);
            qDebug()<<"send letter "<<i<<","<<"j:"<<sendLetter[i][j];
        }
    }


    ui -> tableView->setModel(standItemModel);    //挂载表格模型
    //以下内容为表格格式
    ui -> tableView->horizontalHeader()->setSectionResizeMode(0,QHeaderView::Fixed);  //设定序号和收发栏列宽不可变
    ui -> tableView->horizontalHeader()->setSectionResizeMode(4,QHeaderView::Stretch);//设定主题弹性拉伸
    //设定表格的宽度
    ui -> tableView->setColumnWidth(1,100);

    ui -> tableView->verticalHeader()->hide();    //隐藏默认显示的行头
    ui ->tableView ->hideColumn(0);
    ui ->tableView ->hideColumn(5);
    ui ->tableView ->hideColumn(6);
    ui ->tableView ->hideColumn(7);

    ui -> tableView->setSelectionBehavior(QAbstractItemView::SelectRows); //设置选中时整行选中
    ui -> tableView->setEditTriggers(QAbstractItemView::NoEditTriggers);  //设置表格属性只读，不能编辑
    ui -> tableView->setAlternatingRowColors(true);  // alternative colors
    ui -> tableView->sortByColumn(7,Qt::AscendingOrder);                 //按照时间戳降序排列，也就是最后收到的排在最开头

}

void SendLetterBox::on_tableView_doubleClicked(const QModelIndex &index)
{
    if(index.isValid()){        //如果行数有效，则显示detail
        readLine = index.row();
        qDebug()<<"readLine"<<readLine;
        SendLetterDetail *sendLetterDetail = new SendLetterDetail;
        sendLetterDetail->show();
    }
}
