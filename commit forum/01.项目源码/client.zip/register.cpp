#include "register.h"
#include "ui_register.h"
#include "loginwindow.h"

#include "mysql.h"
#include <QDebug>
#include <QMessageBox>
#include <QToolTip>
#include <QKeyEvent>
#include <QRegExpValidator>

Register::Register(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Register)
{
    initSetRegister();
    setConnect();

    QString IP = "192.168.43.11";
    int port = 8765;

    client = new QTcpSocket();

    //取消已有的连接
    client->abort();

    //连接服务器
    client->connectToHost(IP, port);

    //等待连接成功
    if(!client->waitForConnected(30000))
    {
        qDebug() << "Connection failed!";
        return;
    }
}

Register::~Register()
{
    parentWidget()->show();
    delete ui;
}

void Register::initSetRegister(){
    ui->setupUi(this);
    setWindowTitle("新用户注册");
    ui -> username_le ->setPlaceholderText(tr("请输入数字，英文字母或英文符号(分号除外)"));
    QRegExpValidator *pRevalidotor = new QRegExpValidator(QRegExp("[a-zA-Z0-9!-/:-?]{25}"), this);
    ui-> username_le ->setValidator(pRevalidotor);

}
//槽函数
void Register::judgeEmpty(){


}

bool Register::judgeInputExist(QString nameResult){
    if ( nameResult == "refuse"){
        ui ->username_le->setToolTip(tr("用户名已存在"));
        return true;
    }
    else if( nameResult == "allow" ){
        return false;
    }
}

bool Register::judgeInputEmpty(){
    if( userNameRight.isEmpty() || userAnsRight.isEmpty() ||ui->checkpwd_le->text().isEmpty()||ui->pwd_le->text().isEmpty()|| userQuesRight.isEmpty()){
        return true;
    }
    else{
        return false;
    }
}

bool Register::judgeInputSame(){
    if( ui->checkpwd_le->text() == ui->pwd_le->text() ){
        return true;
    }
    else{
        return false;
    }
}

void Register::toMainPage(){
    QMessageBox::warning(this, tr("提示"),tr("注册成功！"),tr("好的"));
    mainWindow = new MainWindow;
    mainWindow -> show();
    this -> close();
}

void Register::keyPressEvent(QKeyEvent *event){
    qDebug()<<"in KeyPressed,eventkey"<<event->key()<<endl;
    if(event->key() == Qt::Key_Return || event->key() == Qt::Key_Enter){
        qDebug()<<"in KeyPressed QEvent::KeyPress"<<endl;
        if( ui ->username_le -> hasFocus() ){
            ui -> pwd_le -> setFocus();
        }
        else{
            if( ui ->pwd_le -> hasFocus() ){
                ui -> checkpwd_le -> setFocus();
            }
            else{
                if( ui -> checkpwd_le -> hasFocus() ){
                    ui ->ques_le ->setFocus();
                }
                else{
                    if( ui -> ques_le -> hasFocus()){
                        ui->ans_le->setFocus();
                    }
                    else{
                        if( ui ->ans_le ->hasFocus()){
                            judgeEmpty();
                        }
                    }
                }
            }
        }

    }
}

void Register::setConnect(){
    connect( ui -> submit_btn, SIGNAL(clicked()), this,SLOT( judgeEmpty() ));
    connect( ui -> cancel_btn, SIGNAL(clicked()), this,SLOT( cancelToMain()));
}

void Register::cancelToMain(){
    LogInWindow *logInWindow = new LogInWindow;
    logInWindow -> show();
    this -> close();
}

void Register::on_submit_btn_clicked()
{
    qDebug() << "Connect successfully!";

    qDebug() << "Send: " << "send something";

    //获取文本框内容并以ASCII码形式发送
    userNameRight = ui -> username_le -> text();
    userPasswordRight = ui ->pwd_le -> text();
    userAnsRight = ui -> ans_le -> text();
    userQuesRight = ui -> ques_le -> text();

    QJsonObject simp_ayjson;
    simp_ayjson.insert("OPERATION", 2);
    simp_ayjson.insert("USERNAME", userNameRight);
    simp_ayjson.insert("PASSWORD", userPasswordRight);
    simp_ayjson.insert("USERQUES", userQuesRight);
    simp_ayjson.insert("USERANS", userAnsRight);
    QJsonDocument document;
    document.setObject(simp_ayjson);
    QByteArray simpbyte_array = document.toJson(QJsonDocument::Compact);

    client->write(simpbyte_array);

    connect(client, &QTcpSocket::readyRead, [=]() {
      QByteArray array= client->readAll();
      QString array1=array;
      qDebug()<<array1;
      bool isExist = judgeInputExist(array1);

      bool isInputEmpty_reg = true;
      bool isInputSame_reg = false;

      isInputEmpty_reg = judgeInputEmpty();
      isInputSame_reg = judgeInputSame();

      if( isInputEmpty_reg == false && isInputSame_reg == true ){
          qDebug()<<"full ";
          if(isInputEmpty_reg == true){
              qDebug()<<"empty";
              QMessageBox::warning(this, tr("警告"),tr("输入为空！"),QMessageBox::Yes);
          }
          else{
              qDebug()<<"full";
              if( isInputSame_reg == false ){
                  qDebug()<<"not same";
                  QMessageBox::warning(this, tr("警告"),tr("密码输入不一致！"),QMessageBox::Yes);
                  ui->pwd_le->clear();
                  ui->checkpwd_le->clear();
              }
              else{
                  //判断是否匹配
                  qDebug()<<"same";
                  if ( isExist == true ){
                      qDebug()<<"exist";
                      QMessageBox::warning(this, tr("警告"),tr("用户名已存在！"),tr("关闭"));
                  }
                  else{
                      qDebug()<<"not exist,register right";
                      toMainPage();
                  }
              }
          }
      }
      else{
          qDebug()<<"empty and wrong";
          if( userNameNew.contains(";")){
              QMessageBox::warning(this, tr("警告"),tr("用户名内不能有分号！"),tr("关闭"));
              return;
          }

      }





    });

    client->flush();
}
