#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "writeletterwindow.h" //写信件
#include "settings.h" //主题设置
#include "loginwindow.h"

#include <QDialog>
#include <QDebug>
#include <QTimer>
#include <QDateTime>
#include <QKeyEvent>
#include <QString>
#include <QStackedWidget>
#include <QTableView>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{

    ui->setupUi(this);
    setWindowTitle(userNameRight+"的邮箱");
    setTheme();
    timerBuild();

    setConnect();
    /*
    QString IP = "192.168.43.11";
    int port = 8765;

    client = new QTcpSocket();

    //取消已有的连接
    client->abort();

    //连接服务器
    client->connectToHost(IP, port);

    //等待连接成功
    if(!client->waitForConnected(30000))
    {
        qDebug() << "Connection failed!";
        return;
    }
    //on_ReceiveBox_clicked();*/
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::openWriteLetter(){
    qDebug() <<"openWriteLetter"<< endl;
    writeletterW = new WriteLetterWindow;
    writeletterW -> show();
}

void MainWindow::openSettings(){
    qDebug() <<"openSettings"<< endl;
    Settings *settings;
    settings = new Settings;
    settings -> show();
    isTheme = true;
    this -> close();
}

void MainWindow::setConnect(){
    connect( ui -> WriteEmail, SIGNAL(clicked()), this, SLOT( openWriteLetter()) );
    connect( ui -> SettingB, SIGNAL(clicked()), this, SLOT( openSettings()) );
    connect( ui -> help_btn, SIGNAL( clicked() ), this, SLOT( toHelp() ));
    connect( ui ->Logout, SIGNAL( clicked() ), this, SLOT( logOut() ));
}

void MainWindow::setTheme(){
    allText_btn = this -> findChildren<QPushButton*>();
    for(int i = 0;i < buttonNum ;i++){
         allText_btn[i]->setFont( fontType );
         allText_btn[i]->setStyleSheet( fontColorArgb+buttonBackCol );
    }

    allText_lb = this -> findChildren<QLabel*>();
    for(int i = 0 ;i < labelNum ;i++){
         allText_lb[i] -> setStyleSheet( fontColorArgb );
         allText_lb[i] -> setFont( fontType );
    }
    extern QString backGroundColor;
    this -> setStyleSheet(backGroundColor);

    //预先set一个收件箱
}

void MainWindow::timerBuild(){
    /*此处为生成update时间*/
    id1 = startTimer(1000);  // 开启一个1秒定时器，返回其ID
    QTimer *timer = new QTimer(this);
    connect(timer, SIGNAL(timeout()), this, SLOT(timerUpdate()));
    //关联定时器溢出信号和相应的槽函数
    timer->start(1000);
}

void MainWindow::timerUpdate(){
       //获取系统现在的时间
       QDateTime time = QDateTime::currentDateTime();
       //设置系统时间显示格式
       QString str = time.toString("yyyy-MM-dd hh:mm:ss dddd");
       //在标签上显示时间
       ui -> timeUpdate -> setText(str);
}

void MainWindow::rithtClickMenu(QPoint pos){
    /*QModelIndex index = ui -> tableView -> indexAt(pos);    //找到tableview当前位置信息
    if(index.isValid()){        //如果行数有效，则显示菜单
        rightClickMenu->exec(QCursor::pos());
    }*/
}

void MainWindow::menuChooseAction(QAction *act){  //弹出提示框，看是否删除数据
    QMessageBox message(
                QMessageBox::NoIcon, QString::fromLocal8Bit("Warn"),
                QString::fromLocal8Bit("This Mail will be moved"),
                QMessageBox::Yes | QMessageBox::No, NULL);

    /*if(message.exec() == QMessageBox::Yes){
        if(act->text() == QString::fromLocal8Bit("delete/retrive"))   //看选中了删除这个菜单
           ; //model_measure -> removeRow(selected_Current_Row);  //删除掉了表格信息
        }//*/
}

void MainWindow::toHelp(){
    help = new Help();
    help->show();
}

void MainWindow::closeEvent(QCloseEvent *event){
    if (isTheme == true){
        return;
    }
    QMessageBox::StandardButton result=QMessageBox::question(this, "确认", "确定要退出本系统吗？",
                          QMessageBox::Yes|QMessageBox::No,
                          QMessageBox::No);

        if (result == QMessageBox::Yes){
            QApplication* app;
            app->quit();
        }
        else{
            event->ignore();
        }
}

void MainWindow::logOut(){
    QMessageBox::StandardButton result=QMessageBox::question(this, "确认", "确定要退出本系统吗？",QMessageBox::Yes|QMessageBox::No,QMessageBox::No);
        if (result == QMessageBox::Yes){
            LogInWindow *logIn = new LogInWindow;
            logIn->show();
            isTheme = true;
            close();
        }
        else{
            event->ignore();
        }
}

void MainWindow::on_SearchButton_clicked()
{
    //搜索功能
    QString keyWord = ui->textEdit->toPlainText();
    if( !keyWord.isEmpty() ){
        switch(boxState){
        case 1:{
            searchLetterCount = 0;
            for(int i = 0;i< receiveLetterCount ;i++){
                if(receiveLetter[i][4].contains(keyWord)){
                    for(int j = 0;j < 7 ; j++){
                        searchLetter[ searchLetterCount ][j] = receiveLetter[i][j] ;
                    }
                    searchLetterCount ++;
                }
            }
            break;
        }
        case 2:{
            //0-5对应发件人/收件人/密送人/抄送人/主题/邮件详情
            searchLetterCount = 0;
            for(int i = 0;i< sendLetterCount ;i++){
                if(sendLetter[i][4].contains(keyWord)){
                    for(int j = 0;j < 7 ; j++){
                        qDebug()<<"in search";
                        searchLetter[ searchLetterCount][j] = sendLetter[i][j] ;
                    }
                    searchLetterCount++;
                }
            }
            break;
        }
        case 3:{
            searchLetterCount = 0;
            for(int i = 0;i< draftLetterCount ;i++){
                if(draftLetter[i][4].contains(keyWord)){
                    for(int j = 0;j < 7 ; j++){
                        //
                        searchLetter[searchLetterCount][j] = draftLetter[i][j] ;
                    }
                    searchLetterCount++;
                }

            }
            break;
        }
        case 4:{
            searchLetterCount = 0;
            for(int i = 0;i< deleteLetterCount ;i++){
                if(deleteLetter[i][4].contains(keyWord)){
                    for(int j = 0;j < 7 ; j++){
                        searchLetter[ searchLetterCount][j] = deleteLetter[i][j] ;
                    }
                    searchLetterCount++;
                }

            }
            break;
        }
      }
    }
    else{
        searchLetterCount = 0;
    }
    SearchResultWindow *searchResult = new SearchResultWindow;
    searchResult->show();

}

void MainWindow::on_ReceiveBox_clicked()
{
    boxState = 1;
    receiveLetterCount = 0;
    int recv = boxState + 2;
    resetBox(recv);
    receiveLetterWindow =new ReceiveLetterBox(this);
    ui ->stackedWidget->addWidget(receiveLetterWindow);
    ui ->stackedWidget->setCurrentWidget(receiveLetterWindow);
}

void MainWindow::on_SentBox_clicked()
{
    boxState = 2;
    sendLetterCount = 0;
    int sent = boxState + 2;
    resetBox(sent);

    sendLetterWindow =new SendLetterBox(this);
    ui ->stackedWidget->addWidget(sendLetterWindow);
    ui ->stackedWidget->setCurrentWidget(sendLetterWindow);
}

void MainWindow::on_ScriptBox_clicked()
{
    boxState = 3;
    int script = boxState + 2;
    //0-5对应发件人/收件人/密送人/抄送人/主题/邮件详情

    qDebug()<<"in draftLetter";
    resetBox(script);
    draftLetterWindow =new DraftLetterBox(this);
    ui ->stackedWidget->addWidget(draftLetterWindow);
    ui ->stackedWidget->setCurrentWidget(draftLetterWindow);
}

void MainWindow::on_TrashBox_clicked()
{
    boxState = 4;
    int trash = boxState + 2;
    resetBox(trash);

    deleteLetterWindow =new DeleteLetterBox(this);
    ui ->stackedWidget->addWidget(deleteLetterWindow);
    ui ->stackedWidget->setCurrentWidget(deleteLetterWindow);
}
//这里写socket之类的内容

void MainWindow::resetBox(int a){
    QTcpSocket *client;
    QString IP = "192.168.43.11";
    int port = 8765;
    client = new QTcpSocket();
    //取消已有的连接
    client->abort();
    //连接服务器
    client->connectToHost(IP, port);
    //等待连接成功
    if(!client->waitForConnected(30000))
    {
        qDebug() << "Connection failed!";
        return;
    }
    qDebug() << "Connect successfully!";
    qDebug() << "Send: " << "send something";
    qDebug() << "Send: " << userNameRight;

    QJsonObject simp_ayjson;
    qDebug()<<"a = "<<a;
    simp_ayjson.insert("OPERATION", a);
    simp_ayjson.insert("AUDIENCE", userNameRight);
    QJsonDocument document;
    document.setObject(simp_ayjson);
    QByteArray simpbyte_array = document.toJson(QJsonDocument::Compact);

    client->write(simpbyte_array);

    connect(client, &QTcpSocket::readyRead, [=]() {
      QByteArray array= client->readAll();

      QJsonParseError error;
      QJsonDocument document = QJsonDocument::fromJson(array,&error);

      list = document.toVariant().toList();

      //new start
      for(int j = 0;j<100;j++){
          sendLetter[j][7].clear();
          receiveLetter[j][7].clear();
          deleteLetter[j][7].clear();
          draftLetter[j][7].clear();
      }
      qDebug()<<"list count"<<list.count();
      for(int i = 0,tempCount = 0; i<list.count(); i++)
      {
          QVariantMap map = list[i].toMap();
          letter[i][0]=map["SENDER"].toString();

          letter[i][1]=map["RECEIVER1"].toString();//拼接
          if (!map["RECEIVER2"].toString().isEmpty()){
              letter[i][1].append(';');
              letter[i][1].append(map["RECEIVER2"].toString());
                    if (!map["RECEIVER3"].toString().isEmpty()){
                        letter[i][1].append(';');
                        letter[i][1].append(map["RECEIVER3"].toString());
                        if (!map["RECEIVER4"].toString().isEmpty()){
                            letter[i][1].append(';');
                            letter[i][1].append(map["RECEIVER4"].toString());
                            if (!map["RECEIVER5"].toString().isEmpty()){
                                letter[i][1].append(';');
                                letter[i][1].append(map["RECEIVER5"].toString());
                            }
                        }

                    }

          }

          qDebug()<<"receiver:"<<letter[i][1];
          letter[i][2]=map["COPYTO1"].toString();
          if (!map["COPYTO2"].toString().isEmpty()){
              letter[i][2].append(';');
              letter[i][2].append(map["COPYTO2"].toString());
                    if (!map["COPYTO3"].toString().isEmpty()){
                        letter[i][2].append(';');
                        letter[i][2].append(map["COPYTO3"].toString());
                        if (!map["COPYTO4"].toString().isEmpty()){
                            letter[i][2].append(';');
                            letter[i][2].append(map["COPYTO4"].toString());
                            if (!map["COPYTO5"].toString().isEmpty()){
                                letter[i][2].append(';');
                                letter[i][2].append(map["COPYTO5"].toString());
                            }
                        }

                    }
          }

          qDebug()<<"receiverCopy:"<<letter[i][2];

          letter[i][3]=map["SECRET1"].toString();
          if (!map["SECRET2"].toString().isEmpty()){
              letter[i][3].append(';');
              letter[i][3].append(map["SECRET2"].toString());
                    if (!map["SECRET3"].toString().isEmpty()){
                        letter[i][3].append(';');
                        letter[i][3].append(map["SECRET3"].toString());
                        if (!map["SECRET4"].toString().isEmpty()){
                            letter[i][3].append(';');
                            letter[i][3].append(map["SECRET4"].toString());
                            if (!map["SECRET5"].toString().isEmpty()){
                                letter[i][3].append(';');
                                letter[i][3].append(map["SECRET5"].toString());
                                letter[i][3].append(';');
                            }
                        }

                    }
          }

          qDebug()<<"receiverCopy:"<<letter[i][3];

          letter[i][4]=map["TITLE"].toString();
          letter[i][5]=map["TEXT"].toString();
          letter[i][6]=' ';
          //place 1收,2发,3草稿,4删
          //传输过来的东西都是什么?
          qDebug()<<"received!" <<endl;
          for(int j = 0;j<7;j++){
              qDebug()<<"letter is:"<<i<<letter[i][j];
          }
          //将这些分别放到数组中并计数
          switch(a){
          case 3:{
              for(int j=0;j<7;j++){
                  receiveLetter[receiveLetterCount][j]=letter[i][j];
              }
              receiveLetter[receiveLetterCount][7]=receiveLetterCount;
              receiveLetterCount++;
              qDebug()<<"receiveLetter"<<tempCount;
              break;
          }
          case 4:{

              for(int j=0;j<7;j++){
                  sendLetter[sendLetterCount][j]=letter[i][j];
              }
              sendLetter[sendLetterCount][7]=sendLetterCount;
              sendLetterCount++;
              qDebug()<<"sendLetter in case"<<sendLetterCount;
              break;
          }
          case 5:{
              for(int j=0;j<7;j++){
                  draftLetter[draftLetterCount][j]=letter[i][j];
              }
              draftLetter[draftLetterCount][7]=draftLetterCount;
              draftLetterCount++;
              break;
          }
          case 6:{
              for(int j=0;j<7;j++){
                  deleteLetter[deleteLetterCount][j]=letter[i][j];
                  qDebug()<<"delete "<<i<<":"<<deleteLetter[deleteLetterCount][j];
              }
              deleteLetter[deleteLetterCount][7]=deleteLetterCount;
              deleteLetterCount++;
              break;
          }
          }
      }
      });

    client->flush();
    //new end
}
