#ifndef LETTERDETAILWINDOWS_H
#define LETTERDETAILWINDOWS_H

#include "writeletterwindow.h"
#include "saveattach.h"

#include <QMainWindow>
#include <QTextEdit>

extern QFont fontType;
extern QString fontColorArgb;
extern QString buttonBackCol;

namespace Ui {
class LetterDetailWindows;
}

class LetterDetailWindows : public QMainWindow
{
    Q_OBJECT

public:
    explicit LetterDetailWindows(QWidget *parent = nullptr);
    ~LetterDetailWindows();

private:
    Ui::LetterDetailWindows *ui;
    WriteLetterWindow *replyWindow;
    WriteLetterWindow *forwardWindow;
    SaveAttach *saveAttach;

    QList<QPushButton*> allText_btn;
    QList<QLabel*> allText_lb;
    QList<QTextEdit*> allText_te;
    const int labelNum = 4;
    const int buttonNum = 5;
    const int textEditNum = 4;

    QString sendPer;
    QString receiPer;
    QString copyPer;
    QString title;

private slots:
    void openReplyWindow();
    void openForwardWindow();
    void openSaveAttach();

private:
    void setConnect();
    void initSet();

signals:
    void sendSenderData(QString);   //用来传递数据的信号
    void sendThemeData(QString);   //用来传递数据的信号
    void sendContextData(QString);   //用来传递数据的信号
};

#endif // LETTERDETAILWINDOWS_H
