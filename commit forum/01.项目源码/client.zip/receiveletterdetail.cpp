#include "receiveletterdetail.h"
#include "ui_receiveletterdetail.h"

#include <QDebug>

ReceiveLetterDetail::ReceiveLetterDetail(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::ReceiveLetterDetail)
{
    ui->setupUi(this);
    setWindowTitle("邮件详情");
    initSet();
    setConnect();

    ui -> sendSet_lb ->setText(receiveLetter[readLine][0]);
    ui -> receiSet_lb ->setText(receiveLetter[readLine][1]);
    ui -> copySet_lb ->setText(receiveLetter[readLine][2]);
    ui -> titleSet_lb ->setText(receiveLetter[readLine][4]);
    ui -> LetterDetailsContext ->setText(receiveLetter[readLine][5]);


    QString IP = "192.168.43.11";
    int port = 8765;

    client = new QTcpSocket();

    //取消已有的连接
    client->abort();

    //连接服务器
    client->connectToHost(IP, port);

    //等待连接成功
    if(!client->waitForConnected(30000))
    {
        qDebug() << "Connection failed!";
        return;
    }
}

ReceiveLetterDetail::~ReceiveLetterDetail()
{
    delete ui;
}

void ReceiveLetterDetail::openSaveAttach(){
    qDebug() <<"openSaveAttach"<< endl;
    saveAttach = new SaveAttach;
    saveAttach -> show();
}

void ReceiveLetterDetail::setConnect(){
    connect( ui -> SaveAttachB, SIGNAL(clicked()), this, SLOT( openSaveAttach()));
}

void ReceiveLetterDetail::initSet(){
    this -> setStyleSheet(backGroundColor);
    allText_btn = this -> findChildren<QPushButton*>();
    for(int i = 0;i < buttonNum ;i++){
         allText_btn[i]->setFont( fontType );
         allText_btn[i]->setStyleSheet( fontColorArgb + buttonBackCol );
    }

    allText_lb = this -> findChildren<QLabel*>();
    for(int i = 0 ;i < labelNum ;i++){
         allText_lb[i] -> setStyleSheet( fontColorArgb );
         allText_lb[i] -> setFont( fontType );

    }
    allText_te = this -> findChildren<QTextEdit*>();
    for(int i = 0 ;i < textEditNum ;i++){
        allText_lb[i] -> setStyleSheet( fontColorArgb );
        allText_lb[i] -> setFont( fontType );
    }

    //数据库得到邮件详情

}

void ReceiveLetterDetail::on_delete_btn_clicked()
{
    //删除槽函数
    QMessageBox::StandardButton result=QMessageBox::question(this, "确认", "确定要删除吗？",QMessageBox::Yes|QMessageBox::No,QMessageBox::No);
    if (result == QMessageBox::Yes){

         //如果点击了确认删除，则删除
        QJsonObject simp_ayjson;
        simp_ayjson.insert("OPERATION", 10);
        simp_ayjson.insert("AUDIENCE", userNameRight);
        simp_ayjson.insert("TITLE", receiveLetter[readLine][4]);

        qDebug()<<"1:"<<userNameRight;
        qDebug()<<"2:"<<receiveLetter[readLine][4];
        QJsonDocument document;
        document.setObject(simp_ayjson);
        QByteArray simpbyte_array = document.toJson(QJsonDocument::Compact);

        client->write(simpbyte_array);


        qDebug()<<"delete ok";


        QString title = receiveLetter[readLine][4];
        qDebug()<<"title:"<<title;
        //删除结束后

        client->flush();
        QMessageBox::question(this, "关闭", "删除成功！");
        close();
     }
     else{
          //否则取消
     }
}

void ReceiveLetterDetail::on_ReplyB_clicked()
{
    qDebug() <<"openReplyWindow"<< endl;
    receiveLetterState = 1;
    replyWindow = new WriteLetterWindow;
    //1表示点击回复，2表示点击转发
    qDebug()<<"receiveLetterState in reply"<<receiveLetterState;
    replyWindow -> show();
}

void ReceiveLetterDetail::on_SaveAttachB_clicked()
{

   QJsonObject simp_ayjson;
   simp_ayjson.insert("OPERATION", 12);
   simp_ayjson.insert("TITLE", receiveLetter[readLine][4]);

   QJsonDocument document;
   document.setObject(simp_ayjson);
   QByteArray simpbyte_array = document.toJson(QJsonDocument::Compact);

   client->write(simpbyte_array);

   qDebug()<<"trans succeed";

   connect(client, &QTcpSocket::readyRead, [=]() {
       qDebug()<<"connect.";
       QDataStream in(client);
          in.setVersion(QDataStream::Qt_4_6);
          if(bytesReceived <= sizeof(qint64)*2)
          { //如果接收到的数据小于16个字节，那么是刚开始接收数据，我们保存到//来的头文件信息
              qDebug()<<"如果接收到的数据小于16个字节，那么是刚开始接收数据，我们保存到";
              if((client->bytesAvailable() >= sizeof(qint64)*2)
                  && (fileNameSize == 0))
              { //接收数据总大小信息和文件名大小信息
                  qDebug()<<"接收数据总大小信息和文件名大小信息";
                  in >> totalBytes >> fileNameSize;
                  bytesReceived += sizeof(qint64) * 2;
              }
              if((client->bytesAvailable() >= fileNameSize)
                  && (fileNameSize != 0))
              {  //接收文件名，并建立文件
                  qDebug()<<"接收文件名，并建立文件";
                  in >> fileName;

                  bytesReceived += fileNameSize;
                  localFile= new QFile(fileName);
                  if(!localFile->open(QFile::WriteOnly))
                  {
                       qDebug() << "open file error!";
                       return;
                  }
              }
              else return;
          }
          if(bytesReceived < totalBytes)
          {  //如果接收的数据小于总数据，那么写入文件
             bytesReceived += client->bytesAvailable();
             inBlock= client->readAll();
             localFile->write(inBlock);
             inBlock.resize(0);
          }
          if(bytesReceived == totalBytes)
          { //接收数据完成时
           client->close();
           localFile->close();
           ui -> label->setText("下载成功！");
          }
    });
}

void ReceiveLetterDetail::on_ForwardB_clicked()
{
    qDebug() <<"openForwardWindow"<< endl;
    receiveLetterState = 2;
    forwardWindow = new WriteLetterWindow;
    forwardWindow -> show();
}
