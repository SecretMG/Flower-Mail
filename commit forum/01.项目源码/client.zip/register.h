#ifndef REGISTER_H
#define REGISTER_H

#include <QWidget>
#include "mainwindow.h"

#include <QtNetwork>
#include <QMessageBox>
#include <QDebug>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>

extern QString userNameRight;
extern QString userQuesRight;
extern QString userAnsRight;
extern QString userPasswordRight;

extern QFont fontType;

class LogInWindow;

namespace Ui {
class Register;
}

class Register : public QWidget
{
    Q_OBJECT

public:
    explicit Register(QWidget *parent = nullptr);
    ~Register();

private:
    Ui::Register *ui;
    MainWindow *mainWindow;

    QString newPwd;
    QString checkPwd;
    QString userNameNew;
    QString userQues;
    QString userAns;

    bool isUserRight;


private slots:
    void toMainPage();
    void judgeEmpty();
    void keyPressEvent(QKeyEvent * event);
    void cancelToMain();

    void on_submit_btn_clicked();

private:
    void initSetRegister();
    bool judgeInputEmpty();
    bool judgeInputSame();
    bool judgeInputExist(QString name);
    void setConnect();
    void setTheme();
    QTcpSocket *client;
};

#endif // REGISTER_H
