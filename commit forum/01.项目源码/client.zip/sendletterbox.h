#ifndef SENDLETTERBOX_H
#define SENDLETTERBOX_H

#include <QWidget>
#include <QMainWindow>
#include <QLabel>
#include <QWidget>
#include <QTableView>
#include <QHeaderView>
#include <QMenu>
#include <QAction>
#include <QMessageBox>
#include <QStandardItem>
#include <QStandardItemModel>

extern QString sendLetter[100][8];

extern int readLine;
extern int sendLetterCount;

namespace Ui {
class SendLetterBox;
}

class SendLetterBox : public QWidget
{
    Q_OBJECT

public:
    explicit SendLetterBox(QWidget *parent = nullptr);
    ~SendLetterBox();  

private:
    Ui::SendLetterBox *ui;

    QStandardItemModel *standItemModel;
    QMenu *rightClickMenu; //右键点出菜单
    QAction *deleteAction; //删除操作
    QCloseEvent *event;

    QVariantList list;

private slots:
    void on_tableView_doubleClicked(const QModelIndex &index);

private:
    void tableBuild();
};

#endif // SENDLETTERBOX_H
