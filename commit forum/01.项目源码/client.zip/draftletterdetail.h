#ifndef DRAFTLETTERDETAIL_H
#define DRAFTLETTERDETAIL_H

#include <QWidget>
#include <QMainWindow>
#include <QTextEdit>
#include <QPushButton>
#include <QLabel>
#include <QtNetwork>
#include <QMessageBox>
#include <QDebug>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>

extern QFont fontType;
extern QString fontColorArgb;
extern QString buttonBackCol;
extern QString backGroundColor;

extern QString userNameRight;
extern QString draftLetter[100][8];
extern int readLine;

namespace Ui {
class DraftLetterDetail;
}

class DraftLetterDetail : public QWidget
{
    Q_OBJECT

public:
    explicit DraftLetterDetail(QWidget *parent = nullptr);
    ~DraftLetterDetail();

private slots:
    void on_Lsend_clicked();
    void on_LchooseFontColor_clicked();
    void on_LchooseFont_clicked();
    void on_Ldelete_clicked();

private:
    void initSet();

private:
    Ui::DraftLetterDetail *ui;
    QList<QPushButton*> allText_btn;
    QList<QLabel*> allText_lb;
    QList<QTextEdit*> allText_te;
    const int labelNum = 4;
    const int buttonNum = 4;
    const int textEditNum = 5;

    QFont textFont;
    QColor textColor;
    QFont lastFont;
    QColor lastColor;

    QTcpSocket *client;
};

#endif // DRAFTLETTERDETAIL_H
