#ifndef SEARCHRESULTWINDOW_H
#define SEARCHRESULTWINDOW_H

#include "letterdetailwindows.h"
#include "draftletterdetail.h"
#include "sendletterdetail.h"

#include <QMainWindow>

#include <QDialog>
#include <QDebug>
#include <QWidget>
#include <QMessageBox>
#include <QModelIndex>
#include <QStandardItem>
#include <QStandardItemModel>
#include <QTableView>
#include <QHeaderView>
#include <QMenu>
#include <QAction>



extern QString searchLetter[100][8];
extern int searchLetterCount;
extern int readLine;
extern int boxState;

namespace Ui {
class SearchResultWindow;
}

class SearchResultWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit SearchResultWindow(QWidget *parent = nullptr);
    ~SearchResultWindow();

private:
    Ui::SearchResultWindow *ui;
    QStandardItemModel *standItemModel;
    LetterDetailWindows *letterDetailWindows;

private slots:
    void openSDetail(QModelIndex index); //此处之后需要改为传递一个时间戳的函数
    void searchBuild();
    void on_tableView_doubleClicked(const QModelIndex &index);
};

#endif // SEARCHRESULTWINDOW_H
