#ifndef DRAFTLETTERBOX_H
#define DRAFTLETTERBOX_H

#include <QWidget>
#include <QMainWindow>
#include <QLabel>
#include <QWidget>
#include <QTableView>
#include <QHeaderView>
#include <QMenu>
#include <QAction>
#include <QMessageBox>
#include <QStandardItem>
#include <QStandardItemModel>

extern QString draftLetter[100][8];


extern int readLine;
extern int draftLetterCount;

namespace Ui {
class DraftLetterBox;
}

class DraftLetterBox : public QWidget
{
    Q_OBJECT

public:
    explicit DraftLetterBox(QWidget *parent = nullptr);
    ~DraftLetterBox();

private:
    Ui::DraftLetterBox *ui;  
    QStandardItemModel *standItemModel;
    QMenu *rightClickMenu; //右键点出菜单
    QAction *deleteAction; //删除操作
    QCloseEvent *event;

    QVariantList list;

private slots:
    void on_tableView_doubleClicked(const QModelIndex &index);

private:
    void tableBuild();
};

#endif // DRAFTLETTERBOX_H
