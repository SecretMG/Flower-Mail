#ifndef RECEIVELETTERBOX_H
#define RECEIVELETTERBOX_H
#include "ReceiveLetterDetail.h"

#include <QWidget>
#include <QLabel>
#include <QTableView>
#include <QHeaderView>
#include <QMenu>
#include <QAction>
#include <QMessageBox>
#include <QStandardItem>
#include <QStandardItemModel>
#include <QDebug>

extern QString receiveLetter[100][8];
extern int receiveLetterCount;
extern int readLine;

namespace Ui {
class ReceiveLetterBox;
}

class ReceiveLetterBox : public QWidget
{
    Q_OBJECT

public:
    explicit ReceiveLetterBox(QWidget *parent = nullptr);
    void receiveTableBuild();
    ~ReceiveLetterBox();

private:
    Ui::ReceiveLetterBox *ui;
    QStandardItemModel    *standItemModel;
    QMenu *rightClickMenu; //右键点出菜单
    QAction *deleteAction; //删除操作
    ReceiveLetterDetail *receiveLetterDetail;


private slots:
    void rithtClickMenu(QPoint pos); //菜单 点击   获取当前位置
    void menuChooseAction(QAction *act);
    void on_tableView_doubleClicked(const QModelIndex &index);
};

#endif // RECEIVELETTERBOX_H
