#ifndef GLOBAL_H
#define GLOBAL_H

#include <QFont>
#include <QColor>

QColor fontColor;
QFont fontType;
QColor buttonColor;
QColor backColor;

QString buttonBackCol;//改按钮颜色
QString fontColorArgb;//改字体颜色
QString backGroundColor;//改背景颜色
int themeType =0;

QString userNameRight;
QString userQuesRight;
QString userAnsRight;
QString userPasswordRight;//在登录比对用户名正确后拿出来的内容

QString receiveLetter[100][8];//0-5对应发件人/收件人/密送人/抄送人/主题/邮件详情
QString sendLetter[100][8];
QString draftLetter[100][8];
QString deleteLetter[100][8];
QString searchLetter[100][8];

int readLine;
int receiveLetterCount;
int sendLetterCount;
int draftLetterCount;
int deleteLetterCount;
int searchLetterCount;
int boxState;
int receiveLetterState = 0;//0表示点击回复，1表示点击转发


#endif // GLOBAL_H

