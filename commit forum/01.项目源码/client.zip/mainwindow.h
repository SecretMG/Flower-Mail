#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include "writeletterwindow.h"
#include "searchresultwindow.h"
#include "help.h"
#include "sendletterbox.h"
#include "draftletterbox.h"
#include "receiveletterbox.h"
#include "deleteletterbox.h"

#include <QMainWindow>
#include <QLabel>
#include <QWidget>
#include <QTableView>
#include <QHeaderView>
#include <QMenu>
#include <QAction>
#include <QMessageBox>
#include <QStandardItem>
#include <QStandardItemModel>
#include <QWidget>
#include <QtNetwork>
#include <QMessageBox>
#include <QDebug>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>


extern QString userNameRight;

extern QString receiveLetter[100][8];//0-5对应发件人/收件人/密送人/抄送人/主题/邮件详情
extern QString sendLetter[100][8];
extern QString draftLetter[100][8];
extern QString deleteLetter[100][8];
extern QString searchLetter[100][8];

extern int receiveLetterCount;
extern int sendLetterCount;
extern int draftLetterCount;
extern int deleteLetterCount;
extern int searchLetterCount;

extern int boxState;

extern QFont fontType;
extern QString fontColorArgb;
extern QString buttonBackCol;
extern QString userNameRight;

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private:
    Ui::MainWindow *ui;
    WriteLetterWindow *writeletterW;
    SearchResultWindow *searchResult;
    Help *help;

    QList<QPushButton*> allText_btn;
    QList<QLabel*> allText_lb;
    const int buttonNum = 9;
    const int labelNum = 2;
    int id1;//时间设定

    QStandardItemModel *standItemModel;
    QMenu *rightClickMenu; //右键点出菜单
    QAction *deleteAction; //删除操作
    LetterDetailWindows *letterDetailWindows;
    QCloseEvent *event;

    bool isTheme = false;
    QString letter[100][7];
    QVariantList list;

    QTcpSocket *client;

    SendLetterBox *sendLetterWindow;
    DraftLetterBox *draftLetterWindow;
    ReceiveLetterBox *receiveLetterWindow;
    DeleteLetterBox *deleteLetterWindow;

private slots:
    void openWriteLetter();
    void openSettings();
    void timerUpdate();//定时update时间
    void timerBuild();
    void rithtClickMenu(QPoint pos); //菜单 点击   获取当前位置
    void menuChooseAction(QAction *act);
    void toHelp();
    void logOut();

    void on_ReceiveBox_clicked();
    void on_SearchButton_clicked();
    void on_SentBox_clicked();
    void on_ScriptBox_clicked();
    void on_TrashBox_clicked();

private:
    void setConnect();
    void setTheme();
    void closeEvent(QCloseEvent *event);   
    void resetBox(int a);//负责重新连接数据库拉取文件


};
#endif // MAINWINDOW_H
